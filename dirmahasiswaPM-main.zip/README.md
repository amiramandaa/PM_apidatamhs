# dirmahasiswaPM
Aplikasi Android (Java) yang menampilkan data mahasiswa dengan menggunakan FAN + MYSQL serta RecycleView
